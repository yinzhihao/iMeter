package com.zcsmart.caokai.lighting.Utils;

/**
 * Created by caokai on 2016/6/25.
 */
public class UpdateInfoEvent {
    public final String mAccount;
    public final String mElectricNo;

    public UpdateInfoEvent(String account, String electricNo) {
        mAccount = account;
        mElectricNo = electricNo;
    }

    public String getmAccount() {
        return mAccount;
    }

    public String getmElectricNo() {
        return mElectricNo;
    }
}
