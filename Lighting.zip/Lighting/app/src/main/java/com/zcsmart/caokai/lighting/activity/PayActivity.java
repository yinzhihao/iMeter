package com.zcsmart.caokai.lighting.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.zcsmart.caokai.lighting.LightingApp;
import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.JsonTo;
import com.zcsmart.caokai.lighting.Utils.Money;
import com.zcsmart.caokai.lighting.Utils.PaySuccessEvent;
import com.zcsmart.caokai.lighting.Utils.Urls;
import com.zcsmart.caokai.lighting.Utils.Utils;
import com.zcsmart.caokai.lighting.base.BaseActivity;
import com.zcsmart.caokai.lighting.bean.PayBean;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.greenrobot.eventbus.EventBus;

import java.util.Map;

import okhttp3.Call;
import okhttp3.MediaType;

/**
 * 充值
 */
public class PayActivity extends BaseActivity implements TextWatcher,View.OnClickListener {
    private static final String TAG = "PayActivity";
    private Button btn_pay_confirm;
    private EditText et_pay;
    private int money;
    private TextView tv_pays_id,tv_pays_name,tv_pays_address,tv_pays_balance;
    private PayBean payBean;
    private LightingApp application;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        application = LightingApp.getApp();
        initView();
    }

    private void initView(){
        btn_pay_confirm = (Button) findViewById(R.id.btn_pay_confirm);
        et_pay = (EditText) findViewById(R.id.et_pay);
        tv_pays_id  = (TextView) findViewById(R.id.tv_pays_id);
        tv_pays_name = (TextView) findViewById(R.id.tv_pays_name);
        tv_pays_address = (TextView) findViewById(R.id.tv_pays_address);
        tv_pays_balance = (TextView) findViewById(R.id.tv_pays_balance);
        payBean = new PayBean();
        payBean.setElectricNo(application.getElectricNo());
        payBean.setCustomerName("中城科技");
        payBean.setAddress("无锡新区菱湖大道200号E1栋11楼");
        payBean.setBalance(application.getAccount());
        tv_pays_id.setText(payBean.getElectricNo());
        tv_pays_name.setText(payBean.getCustomerName());
        tv_pays_address.setText(payBean.getAddress());
        tv_pays_balance.setText(payBean.getBalance());

        Money.setRegion(et_pay,this);
        et_pay.addTextChangedListener(this);
        btn_pay_confirm.setOnClickListener(this);

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        String number = et_pay.getText().toString().trim();
        if (!TextUtils.isEmpty(number) && !number.equals(".")){
            money = Integer.parseInt(number);
            if (money > 0){
                btn_pay_confirm.setEnabled(true);
                return;
            }
        }
        btn_pay_confirm.setEnabled(false);
    }

    private void CreateOrder(){
        payBean.setAmount(et_pay.getText().toString().trim());
        OkHttpUtils.postString().url(Urls.PAY_CREATE_ORDER)
                .mediaType(MediaType.parse("application/json; charset=utf-8"))
                .content(new Gson().toJson(payBean))
                .build().execute(new StringCallback() {
            @Override
            public void onError(Call call, Exception e, int id) {
                Utils.Toast(PayActivity.this,e.toString());
                dialog.dismiss();
            }

            @Override
            public void onResponse(String response, int id) {
                dialog.dismiss();
                Map<String,String> map = JsonTo.getPayOrder(response);
                String isSuccess = map.get("isSuccess");
                if (isSuccess.equals("true")){
                    Intent intent = new Intent(PayActivity.this,PaySuccessActivity.class);
                    intent.putExtra("paybean",payBean);
                    startActivity(intent);
                    EventBus.getDefault().post(new PaySuccessEvent(map.get("data")));
                    finish();
                } else {
                    Utils.Toast(PayActivity.this,"支付失败");
                }
            }
        });
    }
    private Dialog dialog;
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_pay_confirm:
                dialog = Utils.createLoadingDialog(this,"加载中...");
                dialog.show();
                CreateOrder();
                break;
        }
    }
}
