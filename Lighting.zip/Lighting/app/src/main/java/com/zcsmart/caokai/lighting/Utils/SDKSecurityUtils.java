package com.zcsmart.caokai.lighting.Utils;

import android.content.Context;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Created by caokai on 2016/6/6.
 */
public class SDKSecurityUtils {

    /**
     * 检查手机是否安装了SDK的容器文件
     * @param context
     */
    public static void checkSDKFile(Context context){
        String outDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/by4.pack";
        File file = new File(outDir);
        if (!file.exists()){
            SavePackFile(context);
        }
    }

    public  static void SavePackFile(Context context){
        // 文件转存测试代码
        try
        {
            String outDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/by4.pack";
            FileOutputStream fos = new FileOutputStream(outDir);
            InputStream is = context.getResources().getAssets().open("by4.pack");
            byte[] buffer = new byte[1024 * 100];
            int count = 0;
            while ((count = is.read(buffer)) >= 0)
            {
                fos.write(buffer, 0, count);
            }
            // fos.write(str1.getBytes("utf-8"));
            fos.close();
            is.close();
        } catch (Exception e)
        {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
