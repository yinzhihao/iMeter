package com.zcsmart.caokai.lighting.Utils;

/**
 * Created by zhaokaiqiang on 15/4/9.
 */
public interface LoadFinishCallBack {
	void loadFinish();
}
