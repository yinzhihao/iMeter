package com.zcsmart.caokai.lighting.activity;

import android.Manifest;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.BindSuccessEvent;
import com.zcsmart.caokai.lighting.Utils.OnItemClickLitener;
import com.zcsmart.caokai.lighting.Utils.StartBindEvent;
import com.zcsmart.caokai.lighting.Utils.Utils;
import com.zcsmart.caokai.lighting.adapter.Item_Device_Adapter;
import com.zcsmart.caokai.lighting.base.BaseActivity;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 绑定蓝牙
 */
public class BindBuletoothActivity extends BaseActivity implements OnItemClickLitener{
    private RecyclerView lv_bluetooth_devices;
    private BluetoothAdapter mBluetoothAdapter;
    private List<BluetoothDevice> list;
    private Item_Device_Adapter deviceAdapter;
    private TextView tv_bind_info;
    private static final String TAG = "BindBuletoothActivity";
    private Dialog dialog;
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_COARSE_LOCATION = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_buletooth);

        initView();
        initBuleTooth();
        EventBus.getDefault().register(this);
    }

    private void initView(){
        lv_bluetooth_devices = (RecyclerView) findViewById(R.id.lv_bluetooth_devices);
        tv_bind_info = (TextView) findViewById(R.id.tv_bind_info);
        list = new ArrayList<>();
        deviceAdapter = new Item_Device_Adapter(list,this);
        lv_bluetooth_devices.setLayoutManager(new LinearLayoutManager(this));
        lv_bluetooth_devices.setAdapter(deviceAdapter);
        deviceAdapter.setOnItemClickLitener(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onBindSuccessEvent(BindSuccessEvent event){
        String isConnect = event.getmMsg();
        Log.i(TAG,"--->>bindsuccess:"+isConnect);
        if (dialog.isShowing()){
            dialog.dismiss();
            if (isConnect.equals("yes")){
                finish();
            }
        }
    }

    @Override
    public void onItemClick(View view, int position) {
        dialog = Utils.createLoadingDialog(this,"正在连接中...");
        dialog.show();
        mBluetoothAdapter.cancelDiscovery();
        BluetoothDevice device =  list.get(position);
        EventBus.getDefault().post(new StartBindEvent(device.getAddress()));
    }

    private void initBuleTooth(){
        //判断是否有定位权限，6.0以上手机需要定位权限才能搜索到蓝牙设备
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            //请求权限
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSIONS_REQUEST_ACCESS_COARSE_LOCATION);
        }

        // Register for broadcasts when a device is discovered
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.registerReceiver(mReceiver, filter);

        // Register for broadcasts when discovery has finished
        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.registerReceiver(mReceiver, filter);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() >0){
            for (BluetoothDevice device : pairedDevices){
//                String name = device.getName();
//                if (!TextUtils.isEmpty(name)&&name.startsWith("Dual")){
                    list.add(device);
//                }
            }
            deviceAdapter.notifyDataSetChanged();
        }
        doDiscovery();
    }

    /**
     * Start device discover with the BluetoothAdapter
     */
    private void doDiscovery() {
        // If we're already discovering, stop it
        if (mBluetoothAdapter.isDiscovering()) {
            mBluetoothAdapter.cancelDiscovery();
        }
        // Request discover from BluetoothAdapter
        mBluetoothAdapter.startDiscovery();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Make sure we're not doing discovery anymore
        if (mBluetoothAdapter != null) {
            mBluetoothAdapter.cancelDiscovery();
        }
        // Unregister broadcast listeners
        this.unregisterReceiver(mReceiver);
        EventBus.getDefault().unregister(this);
    }

    // The BroadcastReceiver that listens for discovered devices and
    // changes the title when discovery is finished
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            // When discovery finds a device
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Get the BluetoothDevice object from the Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // If it's already paired, skip it, because it's been listed already
                if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                    String name = device.getName();
//                    if (!TextUtils.isEmpty(name)&&name.startsWith("Dual")){
                        list.add(device);
                        deviceAdapter.notifyDataSetChanged();
//                    }
                }
                // When discovery is finished, change the Activity title
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                if (list.size() == 0) {
                    tv_bind_info.setText("没有搜索到设备");
                } else {
                    tv_bind_info.setText("搜索完成");
                }
            }
        }
    };
}
