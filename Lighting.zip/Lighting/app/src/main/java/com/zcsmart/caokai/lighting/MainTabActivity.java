package com.zcsmart.caokai.lighting;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.zcsmart.caokai.lighting.Utils.BinaryUtil;
import com.zcsmart.caokai.lighting.Utils.BindSuccessEvent;
import com.zcsmart.caokai.lighting.Utils.DeviceLostEvent;
import com.zcsmart.caokai.lighting.Utils.PaySuccessEvent;
import com.zcsmart.caokai.lighting.Utils.Public;
import com.zcsmart.caokai.lighting.Utils.SDKSecurity;
import com.zcsmart.caokai.lighting.Utils.SDKSecurityUtils;
import com.zcsmart.caokai.lighting.Utils.StartBindEvent;
import com.zcsmart.caokai.lighting.Utils.UpdateInfoEvent;
import com.zcsmart.caokai.lighting.Utils.Utils;
import com.zcsmart.caokai.lighting.compment.BluetoothChatService;
import com.zcsmart.caokai.lighting.compment.TabFragmentHost;
import com.zcsmart.caokai.lighting.fragment.MeFragment;
import com.zcsmart.caokai.lighting.fragment.MeterFragment;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * 首页我的电表和我的账户切换页面
 */
public class MainTabActivity extends FragmentActivity {
    public static TabFragmentHost mTabHost;
    private LayoutInflater layoutInflater;
    private String titleArray[];
    private Resources res;
    private Class<?> fragmentArray[] = {MeterFragment.class,
            MeFragment.class};
    private int imageArrayDefault[] = {
            R.mipmap.nav_btn_zd_nor,
            R.mipmap.nav_btn_wd_nor,};

    private int imageArraySelected[] = {
            R.mipmap.nav_btn_zd_sel,
            R.mipmap.nav_btn_wd_sel,
    };
    private BluetoothAdapter mBluetoothAdapter;

    private BluetoothChatService mChatService = null;
    // Debugging
    private static final String TAG = "MainTabActivity";
    private static final boolean D = true;
    private String mConnectedDeviceName = null;
    private LightingApp application;
    private String address;//蓝牙连接的物理地址
    private String site;//表地址，用于与蓝牙电表交互
//    private long mExitTime;
    private String data;//充值命令字符串

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
        setContentView(R.layout.activity_main_tab);

        application = (LightingApp) getApplication();

        initView();
        EventBus.getDefault().register(this);
        initBuleTooth();
        directConnect();
        initSDK();
    }

    private void initSDK(){
        SDKSecurityUtils.checkSDKFile(this);
        SDKSecurity.initSDK();
    }

    /**
     * 如果已经绑定过了直接连接mac地址
     */
    private void directConnect(){
        String mac = application.getBluetoothMac();
        if (!TextUtils.isEmpty(mac)){
            address = mac;
            connectDevice(address, Public.b_secure);
        }
    }

    /**
     * 开始绑定蓝牙设备
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onStartBindEvent(StartBindEvent event){
        address = event.getmMsg();
        connectDevice(address, Public.b_secure);
        Log.i(TAG,"--->>startbind:"+address);
    }

    /**
     * 充值到到AppServer成功，返回数据发送到电表蓝牙模块,充值之前先身份认证
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onPaySuccessEvent(PaySuccessEvent event){
        data = event.getmMsg();
        Log.i(TAG,"--->>data:"+data);
//        sendBinary(BinaryUtil.hex2Bytes(data));
        sendBinary(BinaryUtil.hex2Bytes(Utils.BLUETOOTH_IDIFICATE));//身份认证
    }

    private void connectDevice(String address, boolean secure) {
        // Get the BLuetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mChatService.connect(device, secure);
    }

    private void initBuleTooth(){
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        int check = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH);
        int check2 = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN);
        Log.i(TAG,"--->>check:"+check+" --->>check2:"+check2);
        if (check == PackageManager.PERMISSION_GRANTED && check2 == PackageManager.PERMISSION_GRANTED ){
            //开启蓝牙
            mBluetoothAdapter.enable();
            //wait
            while (!mBluetoothAdapter.isEnabled()) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            mChatService = new BluetoothChatService(this, mHandler);
            if (mChatService != null) {
                // Only if the state is STATE_NONE, do we know that we haven't started already
                if (mChatService.getState() == BluetoothChatService.STATE_NONE) {
                    // Start the Bluetooth chat services
                    mChatService.start();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mChatService != null) mChatService.stop();
        EventBus.getDefault().unregister(this);
    }

    private void sendBinary(byte[] buf) {
        // Check that we're actually connected before trying anything
        if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED) {
            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }
        mChatService.write(buf);
    }

    // The Handler that gets information back from the BluetoothChatService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case Utils.MESSAGE_STATE_CHANGE:
                    if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                    switch (msg.arg1) {
                        case BluetoothChatService.STATE_CONNECTED:
                            EventBus.getDefault().post(new BindSuccessEvent("yes"));
                            application.setConnectStatus(true);//连接状态
                            Utils.Toast(getApplicationContext(),"连接到"+mConnectedDeviceName);
                            //发送读地址命令
                            sendBinary(BinaryUtil.hex2Bytes(Utils.BLUETOOTH_ADDRESS));
                            break;
                        case BluetoothChatService.STATE_CONNECTING:
                            break;
                        case BluetoothChatService.STATE_LISTEN:
                        case BluetoothChatService.STATE_NONE:
                            break;
                    }
                    break;
                case Utils.MESSAGE_WRITE: {
                    break;
                }
                case Utils.MESSAGE_READ: {
                    byte[] writeBuf = (byte[]) msg.obj;
                    byte[] recvData = BinaryUtil.clearBuffer(writeBuf);
                    Log.i(TAG,"--->>replayData:"+new String(BinaryUtil.bytes2Hex(recvData)));
                    byte[] controlBytes = new byte[1];
                    if (recvData.length<12){
                        return;
                    }
                    System.arraycopy(recvData,12,controlBytes,0,1);
                    String control = BinaryUtil.bytes2Hex(controlBytes);
                    switch (control){
                        case "93"://读地址
                            byte[] siteByte = BinaryUtil.binaryDecode(recvData,14,6);
                            site = BinaryUtil.bytes2Hex(siteByte);
                            Log.i(TAG,"--->>表地址："+site);

                            if (!application.getBindStatus()){//绑定成功初始化充值清空钱包
                                Log.i(TAG,"--->>init money");
                                sendBinary(BinaryUtil.hex2Bytes(Utils.BLUETOOTH_IDIFICATE));//身份认证
                            } else {
                                //发送读表号命令
                                String numberCmd = "FE FE FE FE 68 "+site+" 68 11 04 35 37 33 37 21 16 ";
                                sendBinary(BinaryUtil.hex2Bytes(numberCmd));
                            }
                            break;
                        case "91":
                            byte[] flagbyte =BinaryUtil.binaryDecode(recvData,14,4);
                            String flag = BinaryUtil.bytes2Hex(flagbyte);
                            Log.i(TAG,"--->>标识："+flag);
                            if (flag.equals("04000402")){//读表号
                                byte[] numbyte = BinaryUtil.binaryDecode(recvData,18,6);
                                String electricNo = BinaryUtil.bytes2Hex(numbyte);
                                Log.i(TAG,"--->>表号："+electricNo);
                                application.setElectricNo("0980011906");//此处读表号写死
                                EventBus.getDefault().post(new UpdateInfoEvent("","0980011906"));
                                //发送读剩余金额命令
                                String moneyCmd = "FE FE FE FE 68 "+site+" 68 11 04 33 35 C3 33 A9 16 ";
                                sendBinary(BinaryUtil.hex2Bytes(moneyCmd));
                            } else if (flag.equals("00900200")){//读剩余金额
                                byte[] moneybyte = BinaryUtil.binaryDecode(recvData,18,4);
                                String money = BinaryUtil.bytes2Hex(moneybyte);
                                double account = Double.parseDouble(money)*0.01;
                                Log.i(TAG,"--->>剩余金额："+account+"元");
                                EventBus.getDefault().post(new UpdateInfoEvent(account+"",""));
                            }
                            break;
                        case "83"://充值
                            byte[] a = new byte[4];
                            System.arraycopy(recvData,14,a,0,4);
                            String payflag = BinaryUtil.bytes2Hex(a);
                            Log.i(TAG,"--->>pay:"+payflag);
                            if (payflag.equals("3233333A")){
                                Log.i(TAG,"--->>身份认证成功");
                                if (TextUtils.isEmpty(data)){
                                    sendBinary(BinaryUtil.hex2Bytes(Utils.BLUETOOTH_CLEAR));//清零
                                } else {
                                    sendBinary(BinaryUtil.hex2Bytes(data));//充值
                                }
                            } else if (payflag.equals("3234343A")){
                                Log.i(TAG,"--->>钱包清零成功");
                                if (!application.getBindStatus()){
                                    application.setBluetoothMac(address);//绑定电表的mac地址
                                    application.setBindStatus(true);//绑定状态
                                }
                                //发送读表号命令
                                String numberCmd = "FE FE FE FE 68 "+site+" 68 11 04 35 37 33 37 21 16 ";
                                sendBinary(BinaryUtil.hex2Bytes(numberCmd));
                            } else if (payflag.equals("3235343A")){
                                Log.i(TAG,"--->>充值成功");
                                //发送读剩余金额命令
                                String moneyCmd = "FE FE FE FE 68 "+site+" 68 11 04 33 35 C3 33 A9 16 ";
                                sendBinary(BinaryUtil.hex2Bytes(moneyCmd));
                            }
                            break;
                    }
                    break;
                }
                case Utils.MESSAGE_DEVICE_NAME:
                    // save the connected device's name
                    mConnectedDeviceName = msg.getData().getString(Utils.DEVICE_NAME);
                    break;
                case Utils.MESSAGE_TOAST:
                    int toast = msg.getData().getInt(Utils.TOAST,0);
                    if (toast == Utils.MESSAGE_CONNECT_FAIL){
                        Utils.Toast(MainTabActivity.this,"无法连接到设备");
                        EventBus.getDefault().post(new BindSuccessEvent("no"));
                    } else if (toast == Utils.MESSAGE_CONNECT_LOST){
                        Utils.Toast(MainTabActivity.this,"设备断开了连接");
                        application.setConnectStatus(false);
                        EventBus.getDefault().post(new DeviceLostEvent("lost"));
                    }
                    break;
            }
        }
    };

    private void initView() {
        layoutInflater = LayoutInflater.from(this);
        res = MainTabActivity.this.getResources();
        titleArray = res.getStringArray(R.array.nav_switcher_main);

        mTabHost = (TabFragmentHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(),
                R.id.nav_view_container);

        for (int i = 0; i < fragmentArray.length; i++) {
            TabHost.TabSpec tabSpec = mTabHost.newTabSpec(titleArray[i]).setIndicator(
                    getTabItemView(i));
            mTabHost.addTab(tabSpec, fragmentArray[i], null);
        }

        mTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {

            @Override
            public void onTabChanged(String tabId) {
                // setCurrentTab(mTabHost.getCurrentTab());
                for (int i = 0; i < fragmentArray.length; i++) {
                    View view = mTabHost.getTabWidget().getChildAt(i);
                    TextView textView = (TextView) view
                            .findViewById(R.id.itemname);
                    ImageView imageView = (ImageView) view
                            .findViewById(R.id.itemview);

                    if (mTabHost.getCurrentTab() == i) {
                        textView.setTextColor(res
                                .getColor(R.color.textview_title_selected));
                        imageView.setImageResource(imageArraySelected[i]);
//                        view.setBackgroundColor(res.getColor(R.color.textview_title_default));
                    } else {
                        textView.setTextColor(res
                                .getColor(R.color.textview_title_default));
                        imageView.setImageResource(imageArrayDefault[i]);
//                        view.setBackgroundColor(res.getColor(R.color.transparent));
                    }
                }
            }
        });

        mTabHost.getTabWidget().setDividerDrawable(R.color.transparent);
        setCurrentTab(0);
    }

    private void setCurrentTab(int index) {
        mTabHost.setCurrentTab(index);
        View view = mTabHost.getTabWidget().getChildAt(index);
        TextView textView = (TextView) view.findViewById(R.id.itemname);
        ImageView imageView = (ImageView) view.findViewById(R.id.itemview);
        textView.setTextColor(res.getColor(R.color.textview_title_selected));
        imageView.setImageResource(imageArraySelected[index]);
//        view.setBackgroundColor(res.getColor(R.color.textview_title_default));
    }

    private View getTabItemView(int index) {
        View view = layoutInflater.inflate(R.layout.bottom_nav_tab_item, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.itemview);
        imageView.setImageResource(imageArrayDefault[index]);
        TextView textView = (TextView) view.findViewById(R.id.itemname);
        textView.setText(titleArray[index]);
        textView.setTextColor(res.getColor(R.color.textview_title_default));
        textView.setTextSize(9);
        return view;
    }

    public void clickButton(View view){
        switch (view.getId()){
            case R.id.iv_meter_update:
                sendBinary(BinaryUtil.hex2Bytes(Utils.BLUETOOTH_ADDRESS));
                break;
            case R.id.layout_me_clear:
                if(!application.getConnectStatus()){
                    Utils.Toast(MainTabActivity.this,"未连接电表");
                } else {
                    new AlertDialog.Builder(this).setMessage("是否确定初始化电表？").setNegativeButton("取消",null).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            data = "";
                            sendBinary(BinaryUtil.hex2Bytes(Utils.BLUETOOTH_IDIFICATE));//身份认证
                            Utils.Toast(MainTabActivity.this,"钱包清零中...");
                        }
                    }).show();
                }
                break;
        }
    }

//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        if (keyCode == KeyEvent.KEYCODE_BACK) {
//            if ((System.currentTimeMillis() - mExitTime) > 2000) {
//                Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
//                mExitTime = System.currentTimeMillis();
//            } else {
//                finish();
//                System.exit(0);
//            }
//            return true;
//        }
//        return super.onKeyDown(keyCode, event);
//    }

}
