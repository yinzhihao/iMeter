package com.zcsmart.caokai.lighting.bean;

/**
 * 充值记录
 * Created by caokai on 2016/6/12.
 */
public class PayRecord {
    String time;
    String id;
    String money;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }
}
