package com.zcsmart.caokai.lighting;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Window;
import android.view.WindowManager;

import com.zcsmart.caokai.lighting.base.BaseFragmentActivity;

public class MainActivity extends BaseFragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Thread(new ThreadShow()).start();
    }

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1){
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, MainTabActivity.class);
                startActivity(intent);
                finish();
            }
        }
    };

    class ThreadShow implements Runnable {

        @Override
        public void run() {
            try {
                Thread.sleep(1000);
                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
