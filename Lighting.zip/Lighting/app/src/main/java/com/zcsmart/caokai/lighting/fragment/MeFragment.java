package com.zcsmart.caokai.lighting.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.zcsmart.caokai.lighting.LightingApp;
import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.Utils;
import com.zcsmart.caokai.lighting.activity.MeterInforActivity;
import com.zcsmart.caokai.lighting.base.BaseFragment;

/**
 * 我的账户
 * Created by caokai on 2016/6/7.
 */
public class MeFragment extends BaseFragment implements View.OnClickListener {
    private LinearLayout layout_me_meter;
    private boolean isBound;
    private LightingApp application;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        application = LightingApp.getApp();
        isBound = application.getBindStatus();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_me, container, false);
        layout_me_meter = (LinearLayout) view.findViewById(R.id.layout_me_meter);
        layout_me_meter.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.layout_me_meter:
                if (!isBound){
                    Utils.Toast(getActivity(),"请先绑定电表");
                } else {
                    Intent intent = new Intent(getActivity(), MeterInforActivity.class);
                    startActivity(intent);
                }
                break;
        }
    }
}
