package com.zcsmart.caokai.lighting.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;

import com.zcsmart.caokai.lighting.LightingApp;
import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.JsonTo;
import com.zcsmart.caokai.lighting.Utils.Urls;
import com.zcsmart.caokai.lighting.Utils.Utils;
import com.zcsmart.caokai.lighting.adapter.Item_Pay_Adapter;
import com.zcsmart.caokai.lighting.base.BaseActivity;
import com.zcsmart.caokai.lighting.bean.PayRecord;
import com.zcsmart.caokai.lighting.compment.AutoLoadRecyclerView;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;

/**
 * 充值记录
 */
public class PayRecordActivity extends BaseActivity {
    private static final String TAG = "PayRecordActivity";
    private AutoLoadRecyclerView alrv_pay_record;
    private Item_Pay_Adapter adapter;
    private List<PayRecord> list;
    private SwipeRefreshLayout srl_pay_refresh;
    private boolean isShow;
    private static final int STATE_NONE = 0;
    private static final int STATE_REFRESH = 1;
    private static final int STATE_MORE = 2;
    private int currentPage = 1;
    private static final int PAGESIZE = 12;
    private String electricNo;
    private boolean isBottom;
    private Dialog dialog;

    @Override
    protected void onStart() {
        super.onStart();
        isShow = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        isShow = false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_record);

        electricNo = LightingApp.getApp().getElectricNo();
        alrv_pay_record = (AutoLoadRecyclerView) findViewById(R.id.alrv_pay_record);
        srl_pay_refresh = (SwipeRefreshLayout) findViewById(R.id.srl_pay_refresh);
        srl_pay_refresh.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);
        srl_pay_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Refresh();
            }
        });

        list = new ArrayList<>();
        alrv_pay_record.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Item_Pay_Adapter(this,list);
        alrv_pay_record.setAdapter(adapter);
        alrv_pay_record.setLoadMoreListener(new AutoLoadRecyclerView.onLoadMoreListener() {
            @Override
            public void loadMore() {
                if (!isBottom){
                    currentPage ++;
                    Download(currentPage,STATE_MORE);
                } else {
                    Utils.Toast(PayRecordActivity.this,"没有更多了");
                }
            }
        });
        Download(currentPage,STATE_NONE);
        dialog = Utils.createLoadingDialog(this,"加载中...");
        dialog.show();
    }

    private void Download(int page, final int actionType ){
//        Log.d(TAG,"--->>url:"+Urls.PAY_RECORD+electricNo+"/"+page+"/"+PAGESIZE);
        OkHttpUtils.get().url(Urls.PAY_RECORD+electricNo+"/"+page+"/"+PAGESIZE).build().execute(new StringCallback() {
            @Override
            public void onError(Call call, Exception e, int id) {
                Utils.Toast(PayRecordActivity.this,"当前网络状态不好");
                if (dialog.isShowing()){
                    dialog.dismiss();
                }
            }

            @Override
            public void onResponse(String response, int id) {
                if (isShow){
                    if (dialog.isShowing()){
                        dialog.dismiss();
                    }
                    List<PayRecord> recordList = JsonTo.getPayRecordList(response);
                    if (recordList.size()>0){
                        isBottom = false;
                        if (actionType == STATE_REFRESH){
                            list.clear();
                            srl_pay_refresh.setRefreshing(false);
                        }
                        alrv_pay_record.loadFinish();
                        list.addAll(recordList);
                        adapter.notifyDataSetChanged();
                    } else {
                        isBottom = true;
                    }
                }
            }
        });
    }

    private void Refresh(){
        isBottom = false;
        currentPage = 1;
        Download(currentPage,STATE_REFRESH);
    }

}
