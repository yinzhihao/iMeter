package com.zcsmart.caokai.lighting.Utils;

/**
 * Created by caokai on 2016/6/13.
 */
public class Urls {
    public static final String PAY_CREATE_ORDER = "http://61.177.137.35:8081/LightningService.svc/CreateOrder";
    public static final String PAY_RECORD = "http://61.177.137.35:8081/LightningService.svc/GetOrderList/";
}
