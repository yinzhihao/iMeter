package com.zcsmart.caokai.lighting.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.TimeUtils;
import com.zcsmart.caokai.lighting.base.BaseActivity;
import com.zcsmart.caokai.lighting.bean.PayBean;

/**
 * 充值成功
 */
public class PaySuccessActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_success);

        PayBean payBean = (PayBean) getIntent().getSerializableExtra("paybean");
        ((TextView)findViewById(R.id.tv_pay_money)).setText(payBean.getAmount() + "元");
        ((TextView)findViewById(R.id.tv_pay_time)).setText(TimeUtils.getUpdateTime());
        ((TextView)findViewById(R.id.tv_success_id)).setText(payBean.getElectricNo());
        ((TextView)findViewById(R.id.tv_success_name)).setText(payBean.getCustomerName());
        ((TextView)findViewById(R.id.tv_success_address)).setText(payBean.getAddress());
        double balance = Double.parseDouble( payBean.getBalance())+ Double.parseDouble( payBean.getAmount());
        ((TextView)findViewById(R.id.tv_success_balance)).setText(balance + "元");
    }

    public void clickButton(View v){
        switch (v.getId()){
            case R.id.btn_pay_ok:
                finish();
                break;
        }
    }
}
