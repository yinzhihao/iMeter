package com.zcsmart.caokai.lighting.Utils;

import com.zcsmart.caokai.lighting.bean.PayRecord;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by caokai on 2016/6/13.
 */
public class JsonTo {

    /**
     * 支付获得订单
     * @param jsonString
     * @return
     */
    public static Map<String,String> getPayOrder(String jsonString){
        Map<String,String>  map = new HashMap<>();
        try {
            JSONObject object = new JSONObject(jsonString);
            JSONObject head = object.getJSONObject("head");
            String isSuccess = head.getString("IsSuccess");
            map.put("isSuccess",isSuccess);
            JSONObject message = object.getJSONObject("message");
            String data = message.getString("DataContent");
            map.put("data",data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return map;
    }

    public static List<PayRecord> getPayRecordList(String jsonString){
        List<PayRecord> list = new ArrayList<>();
        try {
            JSONObject object = new JSONObject(jsonString);
            JSONObject head = object.getJSONObject("head");
            String isSuccess = head.getString("IsSuccess");
            if (isSuccess.equals("true")){
                JSONArray message = object.getJSONArray("message");
                for (int i = 0; i<message.length();i++){
                    JSONObject item_msg = message.getJSONObject(i);
                    PayRecord payRecord = new PayRecord();
                    payRecord.setId(item_msg.getString("ElectricNo"));
                    payRecord.setMoney(item_msg.getString("Amount"));
                    payRecord.setTime(item_msg.getString("CrateTime"));
                    list.add(payRecord);
                }
                return list;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }
}
