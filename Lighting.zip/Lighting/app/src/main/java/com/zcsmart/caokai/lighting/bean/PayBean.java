package com.zcsmart.caokai.lighting.bean;

import java.io.Serializable;

/**
 * Created by caokai on 2016/6/13.
 */
public class PayBean implements Serializable{
    String ElectricNo;//表单
    String CustomerName;//户名
    String Address;//地址
    String Amount;//充值金额
    String Balance;//当前余额

    public PayBean() {
    }

    public PayBean(String electricNo, String customerName, String address, String amount, String balance) {
        ElectricNo = electricNo;
        CustomerName = customerName;
        Address = address;
        Amount = amount;
        Balance = balance;
    }

    public String getElectricNo() {
        return ElectricNo;
    }

    public void setElectricNo(String electricNo) {
        ElectricNo = electricNo;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }

    public String getBalance() {
        return Balance;
    }

    public void setBalance(String balance) {
        Balance = balance;
    }
}
