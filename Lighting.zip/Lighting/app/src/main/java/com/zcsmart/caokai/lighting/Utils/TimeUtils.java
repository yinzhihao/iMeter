package com.zcsmart.caokai.lighting.Utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by caokai on 2016/6/8.
 */
public class TimeUtils {

    public static String getUpdateTime(){
        Date curDate = new Date(System.currentTimeMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String date = sdf.format(curDate);
        return date;
    }
}
