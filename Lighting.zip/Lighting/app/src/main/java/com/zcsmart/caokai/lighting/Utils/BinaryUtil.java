package com.zcsmart.caokai.lighting.Utils;

/**
 * Created by czj on 16-6-15.
 */
public class BinaryUtil {
    public static String trimAll(String s){
        StringBuilder stringBuilder = new StringBuilder();
        char[] chars=s.toCharArray();
        for(char c:chars){
            if(c!=' '&&c!='\r'&&c!='\t'&&c!='\n'){
                stringBuilder.append(c);
            }
        }
        return stringBuilder.toString();
    }
    public static byte[] hex2Bytes(String hex){
        hex=trimAll(hex);
        byte[] bytes=new byte[hex.length()/2];
        for(int i=0;i<hex.length()/2;i++){
            bytes[i]=(byte)(Integer.parseInt(hex.substring(i*2,i*2+2),16)&0xFF);
        }
        return bytes;
    }

    public static byte[] bcd2Bytes(String bcd){
        return hex2Bytes(bcd);
    }

    public static byte[] ascii2Bytes(String str){
        return str.getBytes();
    }

    public static String bytes2Hex(byte[] bytes){
        StringBuilder sb=new StringBuilder();
        for(byte b:bytes){
            sb.append(String.format("%02X",b));
        }
        return sb.toString();
    }

    /**
     * 编码为电表数据帧（+33并倒序）
     * @param bytes
     * @return
     */
    public static byte[] binaryEncode(byte[] bytes,int offset,int len){
        byte[] ret=new byte[len];
        //+33并倒序
        for(int i=0;i<len;i++){
            ret[i]=(byte)((bytes[offset+len-1-i]+0x33)&0xff);
        }
        return ret;
    }

    /**
     * 解码码为电表数据帧（-33并倒序）
     * @param bytes
     * @return
     */
    public static byte[] binaryDecode(byte[] bytes,int offset,int len){
        byte[] ret=new byte[len];
        //-33并倒序
        for(int i=0;i<len;i++){
            ret[i]=(byte)((bytes[offset+len-1-i]-0x33)&0xff);
        }
        return ret;
    }

    public static byte[] clearBuffer(byte[] writeBuf){
        int len = writeBuf.length;
        int index = 0;
        for (int i =0;i<len;i++){
            if (writeBuf[i]==0x16){
                index = i;
                break;
            }
        }
        byte[] read = new byte[index];
        System.arraycopy(writeBuf,0,read,0,index);
        return read;
    }

}
