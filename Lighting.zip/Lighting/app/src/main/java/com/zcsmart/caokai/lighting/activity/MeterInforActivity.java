package com.zcsmart.caokai.lighting.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.LightingApp;
import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.TimeUtils;
import com.zcsmart.caokai.lighting.base.BaseActivity;
import com.zcsmart.caokai.lighting.compment.RiseNumberTextView;

/**
 * 电表信息
 */
public class MeterInforActivity extends BaseActivity {
    private RiseNumberTextView rntv_meter_money;
    private ImageView iv_meter_update;
    private TextView tv_meter_time;
    private static final int CREATE_OK = 1001;
    private ImageView iv_meter_status;
    private TextView tv_meter_status,tv_meter_electricno;
    private LightingApp application;
    private static final String TAG = "MeterInforActivity";

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case CREATE_OK:
                    if ( rntv_meter_money != null){
                        rntv_meter_money.start();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meter_infor);
        application = LightingApp.getApp();
        initView();
    }

    private void initView(){
        rntv_meter_money = (RiseNumberTextView) findViewById(R.id.rntv_meter_money);
        iv_meter_update = (ImageView) findViewById(R.id.iv_meter_update);
        tv_meter_time = (TextView) findViewById(R.id.tv_meter_time);
        iv_meter_status = (ImageView) findViewById(R.id.iv_meter_status);
        tv_meter_status = (TextView) findViewById(R.id.tv_meter_status);
        tv_meter_electricno = (TextView) findViewById(R.id.tv_meter_electricno);
        iv_meter_update.setVisibility(View.GONE);
        rntv_meter_money.withNumber(Float.parseFloat(application.getAccount()));
        rntv_meter_money.setFromNumber((float) 0.00);
        rntv_meter_money.setDuration(1500);
        tv_meter_time.setText(TimeUtils.getUpdateTime());
        tv_meter_electricno.setText(application.getElectricNo());
        checkConnectStatus();
    }

    private void checkConnectStatus(){
        boolean status =  application.getConnectStatus();
        Log.i(TAG,status+"");
        if (status){
            hasConnect();
        } else{
            noConnect();
        }
    }

    private void noConnect(){
        iv_meter_status.setImageResource(R.drawable.meter_connect_fail);
        tv_meter_status.setText("未连接");
    }

    private void hasConnect(){
        iv_meter_status.setImageResource(R.drawable.meter_connect_success);
        tv_meter_status.setText("已连接");
        handler.sendEmptyMessageDelayed(CREATE_OK,500);
    }
}
