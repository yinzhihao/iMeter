package com.zcsmart.caokai.lighting.fragment;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.LightingApp;
import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.BinaryUtil;
import com.zcsmart.caokai.lighting.Utils.BindSuccessEvent;
import com.zcsmart.caokai.lighting.Utils.DeviceLostEvent;
import com.zcsmart.caokai.lighting.Utils.SDKSecurity;
import com.zcsmart.caokai.lighting.Utils.UpdateInfoEvent;
import com.zcsmart.caokai.lighting.activity.BindBuletoothActivity;
import com.zcsmart.caokai.lighting.activity.MeterInforActivity;
import com.zcsmart.caokai.lighting.activity.PayActivity;
import com.zcsmart.caokai.lighting.activity.PayRecordActivity;
import com.zcsmart.caokai.lighting.adapter.Item_Meter_Adapter;
import com.zcsmart.caokai.lighting.base.BaseFragment;
import com.zcsmart.caokai.lighting.compment.RiseNumberTextView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 我的电表
 * Created by caokai on 2016/6/7.
 */
public class MeterFragment extends BaseFragment implements View.OnClickListener,AdapterView.OnItemClickListener {
    private static final String TAG = "MeterFragment";
    private GridView gridView_meter;
    private Item_Meter_Adapter adapter;
    private List<Map<String,Object>> list;
    private String[] arrTitles;
    private int[] arrPics = new int[]{
            R.mipmap.ic_electricity_meter,R.mipmap.ic_recharge,
            R.mipmap.ic_record,R.mipmap.ic_date
    };

    private LinearLayout layout_meter_bind,layout_meter_bound;
    private Button btn_meter_bind;
    private RiseNumberTextView rntv_meter_money;
    private LightingApp application;
    private ImageView iv_meter_status;
    private TextView tv_meter_status,tv_meter_electricno;
    private boolean isShown;
    private boolean isBound;
    private float initialAccount;//起始余额

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        list = new ArrayList<>();
        arrTitles = getResources().getStringArray(R.array.gv_meter_title);
        for (int i = 0;i<arrTitles.length;i++){
            Map<String,Object> map = new HashMap<>();
            map.put("title",arrTitles[i]);
            map.put("pic",arrPics[i]);
            list.add(map);
        }
        isShown = true;
        adapter = new Item_Meter_Adapter(list,getActivity());
        EventBus.getDefault().register(this);
        application = LightingApp.getApp();
        isBound = application.getBindStatus();
        initialAccount = Float.parseFloat(application.getAccount());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_meter, container, false);
        initView(view);
        return view;
    }

    private void initView(View view){
        gridView_meter = (GridView) view.findViewById(R.id.gridView_meter);
        layout_meter_bind = (LinearLayout) view.findViewById(R.id.layout_meter_bind);
        layout_meter_bound = (LinearLayout) view.findViewById(R.id.layout_meter_bound);
        rntv_meter_money = (RiseNumberTextView) view.findViewById(R.id.rntv_meter_money);
        btn_meter_bind = (Button) view.findViewById(R.id.btn_meter_bind);
        iv_meter_status = (ImageView) view.findViewById(R.id.iv_meter_status);
        tv_meter_status = (TextView) view.findViewById(R.id.tv_meter_status);
        tv_meter_electricno = (TextView) view.findViewById(R.id.tv_meter_electricno);
        btn_meter_bind.setOnClickListener(this);
        gridView_meter.setAdapter(adapter);
        gridView_meter.setOnItemClickListener(this);
        String mac = application.getBluetoothMac();
        if (TextUtils.isEmpty(mac)){
            showBind();
        } else {
            showBound();
        }
        tv_meter_electricno.setText(application.getElectricNo());
    }

    private void noConnect(){
        iv_meter_status.setImageResource(R.drawable.meter_connect_fail);
        tv_meter_status.setText("未连接");
    }

    private void hasConnected(){
        iv_meter_status.setImageResource(R.drawable.meter_connect_success);
        tv_meter_status.setText("已连接");
        isBound = true;
        showMoney((float) 0.00,initialAccount);
    }

    private void showMoney(float from,float to){
        rntv_meter_money.withNumber(to);
        rntv_meter_money.setFromNumber(from);
        rntv_meter_money.setDuration(1500);
        rntv_meter_money.start();
    }

    /**
     * 显示绑定
     */
    private void showBind(){
        layout_meter_bind.setVisibility(View.VISIBLE);
        layout_meter_bound.setVisibility(View.GONE);
    }

    /**
     * 显示已经绑定过的我的电表界面
     */
    private void showBound(){
        layout_meter_bind.setVisibility(View.GONE);
        layout_meter_bound.setVisibility(View.VISIBLE);
    }

    /**
     * 设备绑定事件
     * @param event 返回“yes”绑定成功：“no”绑定不成功
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onBindSuccessEvent(BindSuccessEvent event){
        String isConnect = event.getmMsg();
        Log.i(TAG,"--->>isConnect:"+isConnect);
        if (isConnect.equals("yes")){
            showBound();
            hasConnected();
        }
    }

    /**
     * 设备断开连接事件
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDeviceLostEvent(DeviceLostEvent event){
        String lost = event.getmMsg();
        if (lost.equals("lost") && isShown){        noConnect();
        }
    }

    /**
     * 从电表获取信息成功
     * account:账户余额
     * electricNo:表号
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onUpdateInfoEvent(UpdateInfoEvent event){
        String account = event.getmAccount();
        String electricNo = event.getmElectricNo();
        if (!TextUtils.isEmpty(account)){
            initialAccount = Float.parseFloat(application.getAccount());
            showMoney(initialAccount,Float.parseFloat(account));
            application.setAccount(account);
        }
        if (!TextUtils.isEmpty(electricNo)){
            tv_meter_electricno.setText(electricNo);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        isShown = false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_meter_bind:
                BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                if (mBluetoothAdapter != null) {
                    if (mBluetoothAdapter.isEnabled()){
                        Intent intent = new Intent(getActivity(), BindBuletoothActivity.class);
                        startActivity(intent);
                    }
                }
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        if (!isBound){
//            Utils.Toast(getActivity(),"请先绑定电表");
//            return;
//        }
        Intent intent = new Intent();
        switch (position){
            case 0:
                intent.setClass(getActivity(),MeterInforActivity.class);
                startActivity(intent);
                break;
            case 1:
                intent.setClass(getActivity(),PayActivity.class);
                startActivity(intent);
                break;
            case 2:
                intent.setClass(getActivity(), PayRecordActivity.class);
                startActivity(intent);
                break;
            case 3:
                testSDKSign();
                break;
        }
    }


    private void testSDKSign(){
        byte[] b = new byte[8];
        Random r = new Random();
        r.nextBytes(b);
        byte[] signStr = SDKSecurity.signData(b);
        boolean validSign = SDKSecurity.validSign(b,signStr,SDKSecurity.getCpkID());
        Log.i(TAG,"--->>validSign:"+validSign);
        String heads = "0082000068";
        Log.i(TAG,"--->>first:"+heads+ BinaryUtil.bytes2Hex(b)+"40");
        byte[] head = BinaryUtil.hex2Bytes(heads);
        byte[] result = byteAdd(head,head);
        Log.i(TAG,"--->>first2:"+BinaryUtil.bytes2Hex(result));
        Log.i(TAG,"--->>cokid:"+new String(SDKSecurity.getCpkID()));
    }

    public byte[] byteAdd(byte[] data1,byte[] data2){
        byte[] data3 = new byte[data1.length+data2.length];
        System.arraycopy(data1,0,data3,0,data1.length);
        System.arraycopy(data2,0,data3,data1.length,data2.length);
        return data3;
    }
}
