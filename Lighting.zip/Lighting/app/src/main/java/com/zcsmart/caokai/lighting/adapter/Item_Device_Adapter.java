package com.zcsmart.caokai.lighting.adapter;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.Utils.OnItemClickLitener;

import java.util.List;

/**
 * Created by caokai on 2016/6/12.
 */
public class Item_Device_Adapter extends RecyclerView.Adapter{
    private List<BluetoothDevice> list;
    private Context context;
    private OnItemClickLitener mOnItemClickLitener;
    public void setOnItemClickLitener(OnItemClickLitener mOnItemClickLitener) {
        this.mOnItemClickLitener = mOnItemClickLitener;
    }

    public Item_Device_Adapter(List<BluetoothDevice> list,Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_device,parent,false);
        return new DeviceCellHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final DeviceCellHolder deviceHolder = (DeviceCellHolder)holder;
        if (list.size()>0){
            String name = list.get(position).getName();
            if (TextUtils.isEmpty(name)){
                name = list.get(position).getAddress();
            }
            deviceHolder.tv_device_name.setText(name);
        }
        if (mOnItemClickLitener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = deviceHolder.getLayoutPosition();
                    mOnItemClickLitener.onItemClick(deviceHolder.itemView, pos);
                }
            });
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class DeviceCellHolder extends RecyclerView.ViewHolder{
        TextView tv_device_name;

        public DeviceCellHolder(View itemView){
            super(itemView);
            tv_device_name = (TextView) itemView.findViewById(R.id.tv_device_name);
        }
    }

    public BluetoothDevice getDevice(int position) {
        return list.get(position);
    }

}
