package com.zcsmart.caokai.lighting.Utils;


import android.os.Environment;
import android.util.Base64;
import android.util.Log;

import company.com.CkeysTypeEnum;
import company.com.EncTypeEnum;
import company.com.HashTypeEnum;
import company.com.SDKUtil;
import company.com.SecurityLibExecption;

/**
 * cpk安全容器控件
 * @author wangs
 * @date 2016年3月25日
 */
public class SDKSecurity { 
	


	private static byte[] cpkID=null;
	
	static{

		initSDK();
	}
	
	public static boolean initSDK(){
		int a = -1;
		try {
			String path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/";
			String libPath = path+"by4.pack";
			a = SDKUtil.initContailer(libPath);
			System.out.println(a);

			Log.i("caokai","--->>sdk init success");
			return true;
		} catch (SecurityLibExecption securityLibExecption) {
			securityLibExecption.printStackTrace();

			Log.i("caokai","--->>sdk init fail");
		}
		return false;
	}
	
	/**
	 * 获取cpkID
	 * @return
	 */
	public static byte[] getCpkID(){
		if(cpkID==null){
			try {
				cpkID = SDKUtil.getSecurtiyId();
			} catch (SecurityLibExecption e) {
				e.printStackTrace();
			}
		}
		return cpkID;
	}

	public static String getCpkIdStr()
	{
		String cpkStr= new String(Base64.encode(getCpkID(),Base64.NO_WRAP));
		return cpkStr;
	}



	/**
	 * 签名
	 * @return
	 */
	public static byte[] signData(byte[] signData){
		byte[] signResult = null;
		try {
			signResult=SDKUtil.signData(HashTypeEnum.SHA256, signData, 20);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return signResult;
	}

	/**
	 * 验签
	 * @return
	 */
	public static  boolean validSign(byte[] plainData,byte[] signData,byte[] cpkId){
		try {
			int check = SDKUtil.signCheck(HashTypeEnum.SHA256, cpkId, plainData, 20, signData);
			if(check==0){
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 解密
	 * @param encryptStr
	 * @return
	 */
	public static String decodeData(String encryptStr){
		String decStr=null;
		try {
			byte[] encryptData= Base64.decode(encryptStr,Base64.NO_WRAP);
			byte[] decResult = SDKUtil.decData(CkeysTypeEnum.CKEYS80, EncTypeEnum.AES256,encryptData);
			decStr=new String(decResult,"utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decStr;
	}

	/**
	 * 加密
	 * @param plainStr

	 * @return
	 */
	public static String encryptData(String plainStr){
		String encStr=null;
		try {
			byte[] plainData=plainStr.getBytes();

			byte[] encResult =SDKUtil.encData(CkeysTypeEnum.CKEYS80, EncTypeEnum.AES256, plainData, getCpkID());
			encStr= new String(Base64.encode(encResult,Base64.NO_WRAP));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encStr;
	}


	/**
	 * 加密
	 * @param plainStr

	 * @return
	 */
	public static String encryptDataFps(String plainStr,String FpsKey){
		String encStr=null;
		try {
			byte[] plainData=plainStr.getBytes();
			byte[] fpsKeyData= Base64.decode(FpsKey,Base64.NO_WRAP);
			byte[] encResult =SDKUtil.encData(CkeysTypeEnum.CKEYS80, EncTypeEnum.AES256, plainData, fpsKeyData);
			encStr= new String(Base64.encode(encResult,Base64.NO_WRAP));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encStr;
	}
}
