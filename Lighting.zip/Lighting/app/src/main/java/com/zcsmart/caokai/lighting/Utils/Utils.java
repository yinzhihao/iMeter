package com.zcsmart.caokai.lighting.Utils;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zcsmart.caokai.lighting.R;

/**
 * Created by caokai on 2016/6/13.
 */
public class Utils {
    public static final String BLUETOOTH_IDIFICATE = "fe fe fe fe 68 11 11 11 11 11 11 68 03 20 32 33 33 3a ab 89 67 45 01 d9 d1 56 bb 9f 6e 03 7c a5 f1 15 9d f8 b9 1b 48 c3 ab 89 67 45 33 33 b8 16 ";//身份认证命令
    public static final String BLUETOOTH_CLEAR = "fe fe fe fe 68 11 11 11 11 11 11 68 03 1e 32 34 34 3a ab 89 67 45 73 75 42 33 33 33 33 33 a4 20 27 27 33 33 33 33 33 33 05 c5 8a 7a 46 16 ";  //钱包清零命令
    public static final String BLUETOOTH_ADDRESS = "FE FE FE FE 68 AA AA AA AA AA AA 68 13 00 DF 16 ";//读地址命令

    public static final String APP_PREFERENCE = "lighting_preference";

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    public static final int MESSAGE_CONNECT_FAIL = 6;
    public static final int MESSAGE_CONNECT_LOST = 7;

    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_ENABLE_BT = 3;

    public static void Toast(Context context,String string){
        Toast.makeText(context,string,Toast.LENGTH_SHORT).show();
    }

    /**
     * 得到自定义的progressDialog
     * @param context
     * @param msg
     * @return
     */
    public static Dialog createLoadingDialog(Context context, String msg) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View v = inflater.inflate(R.layout.layout_loading, null);// 得到加载view
        LinearLayout layout = (LinearLayout) v.findViewById(R.id.dialog_view);// 加载布局
        // main.xml中的ImageView
        ImageView spaceshipImage = (ImageView) v.findViewById(R.id.img);
        TextView tipTextView = (TextView) v.findViewById(R.id.tipTextView);// 提示文字
        // 加载动画
        Animation hyperspaceJumpAnimation = AnimationUtils.loadAnimation(
                context, R.anim.loading_animation);
        // 使用ImageView显示动画
        spaceshipImage.startAnimation(hyperspaceJumpAnimation);
        tipTextView.setText(msg);// 设置加载信息

        Dialog loadingDialog = new Dialog(context, R.style.loading_dialog);// 创建自定义样式dialog

        loadingDialog.setCancelable(true);// 可以用“返回键”取消
        loadingDialog.setCanceledOnTouchOutside(false);
        loadingDialog.setContentView(layout, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));// 设置布局
        return loadingDialog;

    }
}
