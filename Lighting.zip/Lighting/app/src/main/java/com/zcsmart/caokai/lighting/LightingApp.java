package com.zcsmart.caokai.lighting;

import android.app.Activity;
import android.app.Application;
import android.content.SharedPreferences;

import com.zcsmart.caokai.lighting.Utils.Utils;
import com.zhy.http.okhttp.OkHttpUtils;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

/**
 * Created by caokai on 2016/6/8.
 */
public class LightingApp extends Application {
    private static LightingApp application;

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000L, TimeUnit.MILLISECONDS)
                .readTimeout(10000L, TimeUnit.MILLISECONDS)
                //其他配置
                .build();
        OkHttpUtils.initClient(okHttpClient);
        Thread.setDefaultUncaughtExceptionHandler(new MyUnCaughtExceptionHandler());
    }

    /**
     * 报错不弹对话框
     */
    class MyUnCaughtExceptionHandler implements Thread.UncaughtExceptionHandler{

        @Override
        public void uncaughtException(Thread thread, Throwable ex) {
            ex.printStackTrace();
            // do some work here
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);

        }
    }


    /** 获取Application */
    public static LightingApp getApp() {
        return application;
    }

    /**
     * 电表物理地址
     * @param mac
     */
    public void setBluetoothMac(String mac) {
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("mac", mac);
        editor.commit();
    }

    public String getBluetoothMac() {
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        return sharedPreferences.getString("mac", "");
    }

    /**
     * 连接状态
     * @param connectStatus
     */
    public void setConnectStatus(boolean connectStatus){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("connectStatus",connectStatus);
        editor.commit();
    }

    public boolean getConnectStatus(){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        return sharedPreferences.getBoolean("connectStatus",false);
    }

    /**
     * 绑定状态
     * @param bindStatus
     */
    public void setBindStatus(boolean bindStatus){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("bindStatus",bindStatus);
        editor.commit();
    }

    public boolean getBindStatus(){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        return sharedPreferences.getBoolean("bindStatus",false);
    }

    public void setElectricNo(String electricNo){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("electricNo",electricNo);
        editor.commit();
    }

    public String getElectricNo(){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        return sharedPreferences.getString("electricNo","0000000000");
    }

    public void setAccount(String account){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("account",account);
        editor.commit();
    }

    public String getAccount(){
        SharedPreferences sharedPreferences = getSharedPreferences(
                Utils.APP_PREFERENCE, Activity.MODE_PRIVATE);
        return sharedPreferences.getString("account","0.00");
    }
}
