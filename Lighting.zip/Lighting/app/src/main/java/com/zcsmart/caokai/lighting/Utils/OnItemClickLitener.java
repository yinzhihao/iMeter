package com.zcsmart.caokai.lighting.Utils;

import android.view.View;

/**
 * Created by Administrator on 2015/7/8.
 */
public interface OnItemClickLitener {
    void onItemClick(View view, int position);
}
