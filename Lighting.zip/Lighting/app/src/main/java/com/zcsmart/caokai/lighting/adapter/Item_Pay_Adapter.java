package com.zcsmart.caokai.lighting.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.bean.PayRecord;

import java.util.List;

/**
 * Created by caokai on 2016/6/12.
 */
public class Item_Pay_Adapter extends RecyclerView.Adapter {
    private Context context;
    private List<PayRecord> list;

    public Item_Pay_Adapter(Context context,List<PayRecord> list){
        this.context = context;
        this.list = list;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pay_record,parent,false);
        return new PayRecordHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        PayRecordHolder payHolder = (PayRecordHolder)holder;
        if (list.size()>0){
            PayRecord payRecord = list.get(position);
            payHolder.tv_pay_time.setText(payRecord.getTime());
            payHolder.tv_pay_id.setText(payRecord.getId());
            payHolder.tv_pay_money.setText(payRecord.getMoney()+"元");
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class PayRecordHolder extends RecyclerView.ViewHolder{
        TextView tv_pay_time,tv_pay_id,tv_pay_money;
        public PayRecordHolder(View itemView){
            super(itemView);
            tv_pay_time = (TextView) itemView.findViewById(R.id.tv_pay_time);
            tv_pay_id = (TextView) itemView.findViewById(R.id.tv_pay_id);
            tv_pay_money = (TextView) itemView.findViewById(R.id.tv_pay_money);
        }
    }
}
