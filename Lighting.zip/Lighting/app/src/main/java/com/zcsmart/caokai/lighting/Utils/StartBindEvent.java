package com.zcsmart.caokai.lighting.Utils;

/**
 * Created by caokai on 2016/6/8.
 */
public class StartBindEvent {
    public final String mMsg;
    public StartBindEvent(String msg){
        mMsg = msg;
    }
    public String getmMsg(){
        return mMsg;
    }
}
