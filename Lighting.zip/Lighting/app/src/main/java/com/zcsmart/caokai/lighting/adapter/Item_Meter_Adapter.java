package com.zcsmart.caokai.lighting.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.zcsmart.caokai.lighting.R;
import com.zcsmart.caokai.lighting.base.BaseViewHolder;

import java.util.List;
import java.util.Map;

/**
 * Created by caokai on 2016/6/7.
 */
public class Item_Meter_Adapter extends BaseAdapter{
    private List<Map<String,Object>> list;
    private Context context;

    public Item_Meter_Adapter(List<Map<String, Object>> list,Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.item_meter,parent,false);
        }
        ImageView iv_item_meter = BaseViewHolder.get(convertView,R.id.iv_item__meter);
        TextView tv_item_meter = BaseViewHolder.get(convertView,R.id.tv_item_meter);
        Map<String,Object> map = list.get(position);
        tv_item_meter.setText(map.get("title").toString());
        iv_item_meter.setImageResource((Integer) map.get("pic"));
        return convertView;
    }
}
